import time
import requests
from telegram import Bot

API_TOKEN = "7935361710:AAHou5LKI0_8jFtQa_-2WcuAR-i1G8eS3Sg"
CHAT_ID = "@ratulquotexbot_bot"  # If it's a user ID, use it as a number

bot = Bot(token=API_TOKEN)

ASSETS = ["URUUSD", "BRLUSD", "BDTUSD"]
TRADE_DURATION = "1-minute"

def generate_signal():
    from random import choice
    direction = choice(["UP", "DOWN"])
    asset = choice(ASSETS)
    return asset, direction

def send_signal():
    asset, direction = generate_signal()
    message = f"📢 Quotex Signal\n\n" \
              f"🪙 Asset: {asset}\n" \
              f"📊 Direction: {direction}\n" \
              f"⏱ Duration: {TRADE_DURATION}\n\n" \
              f"✅ Trade wisely!"
    bot.send_message(chat_id=CHAT_ID, text=message)

if __name__ == "__main__":
    while True:
        send_signal()
        time.sleep(300)  # wait 5 minutes
